# StudySphere – Student Study Planner and Progress Tracker

A full-stack MERN web application for managing student study tasks, deadlines, priorities, and progress.

## Technologies
React, Vite, Axios, Node.js, Express.js, MongoDB, Mongoose, HTML, CSS.

## Features
- Create, view, edit, and delete tasks
- Search tasks by title, subject, status, or priority
- Frontend and backend validation
- Deletion confirmation and error messages
- Dashboard with task statistics and progress
- Subject-wise completion tracking

## Prerequisites
Node.js (recent LTS), npm, MongoDB Community Server running locally (or MongoDB Atlas).

## Run locally
1. Open terminal in `backend`.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and configure `MONGO_URI`.
4. Start MongoDB locally if using the example URI.
5. Run `npm run dev`. API starts at http://localhost:5000.
6. Open a second terminal in `frontend`.
7. Run `npm install` then `npm run dev`.
8. Open the localhost URL printed by Vite (usually http://localhost:5173).

## API
- GET /api/tasks
- POST /api/tasks
- PUT /api/tasks/:id
- DELETE /api/tasks/:id

## Testing
Try creating, searching, editing, marking complete and deleting a task. Submit an empty title to verify validation. Stop the backend to verify the frontend connection error.

## Security
Do not commit `.env`, passwords, or database credentials. `.env.example` contains only a local sample configuration.

## Notes
This is a single-user academic demo, not a production authentication system.
