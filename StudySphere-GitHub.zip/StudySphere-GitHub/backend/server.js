import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());
const schema = new mongoose.Schema({
 title:{type:String,required:[true,"Title is required"],trim:true,minlength:2,maxlength:100},
 subject:{type:String,required:[true,"Subject is required"],trim:true,minlength:2,maxlength:60},
 description:{type:String,default:"",maxlength:500},
 priority:{type:String,enum:["Low","Medium","High"],default:"Medium"},
 status:{type:String,enum:["Pending","In Progress","Completed"],default:"Pending"},
 dueDate:{type:String,required:[true,"Due date is required"],validate:{validator:v=>/^\d{4}-\d{2}-\d{2}$/.test(v)&&!Number.isNaN(Date.parse(v)),message:"Use a valid YYYY-MM-DD date"}}
},{timestamps:true});
const Task=mongoose.model("Task",schema);
const fail=(res,e)=>res.status(e.name==="ValidationError"||e.name==="CastError"?400:500).json({message:e.message});
app.get("/api/tasks",async(req,res)=>{try{const tasks=await Task.find().sort({dueDate:1,createdAt:-1});res.json(tasks)}catch(e){fail(res,e)}});
app.post("/api/tasks",async(req,res)=>{try{const task=await Task.create(req.body);res.status(201).json(task)}catch(e){fail(res,e)}});
app.put("/api/tasks/:id",async(req,res)=>{try{const task=await Task.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});if(!task)return res.status(404).json({message:"Task not found"});res.json(task)}catch(e){fail(res,e)}});
app.delete("/api/tasks/:id",async(req,res)=>{try{const task=await Task.findByIdAndDelete(req.params.id);if(!task)return res.status(404).json({message:"Task not found"});res.json({message:"Task deleted"})}catch(e){fail(res,e)}});
app.get("/",(_,res)=>res.json({message:"StudySphere API running"}));
const port=process.env.PORT||5000;
mongoose.connect(process.env.MONGO_URI||"mongodb://127.0.0.1:27017/studysphere")
.then(()=>app.listen(port,()=>console.log(`API running at http://localhost:${port}`)))
.catch(e=>{console.error("MongoDB connection failed:",e.message);process.exit(1)});
